# Additional Findings and Future Directions

This section provides supplementary insights for researchers interested in extending this work or exploring related directions.

## Limitations of the Current Method
- **Seed sensitivity:** The model’s performance varies notably across different random seeds. This instability likely arises from the CNN in the FFT-Block, which learns to encode frequency values that span a wide magnitude range.
- **Scaling limitations:** When evaluated on larger datasets, the method’s performance gains over state-of-the-art (SOTA) approaches were less pronounced. Both this and the previous limitation are attributed to the lack of optimal normalization applied to frequency data before training the CNN encoder.

## Potential Improvements
- **Center cropping rFFT:** Although the rFFT variant performed worse than our proposed FFT-based preprocessing in the ablation study, retrieving a center crop from the rFFT could increase efficiency by approximately 200% — a straightforward optimization opportunity.
- **Spectral Batch Normalization:** The paper *“Spectral Batch Normalization: Normalization in the Frequency Domain”* proposes a normalization strategy specifically designed for frequency data. This approach was not tested here, but applying such normalization prior to CNN encoding could substantially enhance stability and performance.
- **Pretrained frequency encoder:** Instead of training the CNN encoder in the FFT-Block end-to-end, one could pretrain the encoder using a reconstruction loss on frequency data, then freeze it during WSI classification. This approach may enable more efficient training and allow for the use of larger WSI crop sizes.
- **Late-layer batch normalization:** While batch normalization was generally avoided in this work, it may still be beneficial in the later CNN layers of the FFT-Block. If effective, it could eliminate the need for Min-Max scaling and further improve performance.

## Other Applications
- **Generalization:** The proposed method likely generalizes well to large-resolution imagery beyond computational pathology. In particular, geospatial imaging represents a promising and accessible application area for this frequency-based approach.

## Additional Findings
- **Reconstruction quality:** Although not discussed in the paper, we compared the reconstruction quality of several compression methods. While our method achieved the highest reconstruction score, bicubic interpolation produced nearly identical results. This suggests bicubic interpolation may serve as a simpler, compatible alternative for standard deep learning workflows.
- **Multi-scale convolution kernels:** We observed improved performance when using multiple convolution kernel sizes (e.g., 1×1, 3×3, 5×5, etc.) within each CNN layer in the FFT-Block. This aligns with findings from *“A Fourier Frequency Domain Convolutional Neural Network for Remote Sensing Crop Classification Considering Global Consistency and Edge Specificity”* (see Figure 5), which highlights the benefits of multi-scale feature extraction in frequency-space CNNs.

## Intuition
- **Frequency-only improvement:** The frequency-only approach might be able to be further improved.
- **Model specialization:** While CNNs can effectively process frequency-domain information, they were originally designed for spatial data. Developing a frequency-specialized alternative could lead to more efficient and expressive representations of frequency-domain inputs.

## Personal Statement
**Future direction:** My future research will focus on robotics, and I do not plan to continue this specific line of investigation. However, I hope these details assist others who wish to build upon this foundation.  

Cheers,  
**Anthony**
